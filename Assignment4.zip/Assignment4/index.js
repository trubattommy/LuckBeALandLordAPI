const mongoose = require("mongoose");
const mongoURL = "mongodb+srv://userDb:0000@cluster0.seniy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
const connectionOptions = {useNewUrlParser: true, useUnifiedTopology: true}
const express = require("express");
const app = express();
app.use(express.json())
const HTTP_PORT = process.env.PORT || 8080;
const Schema = mongoose.Schema
const ItemSchema = new Schema({
   name:String
})

const Item = mongoose.model("items_table", ItemSchema)

let items = [
    {
        "item": "Magpie",
        "rarity":"common",
        "description": "Gives 9 gold every 4 spins",
        "gold per turn": "-1" 
    },
    {
        "item": "King Midas",
        "rarity":"rare",
        "description": "Adds 1 Gold each turn. Adjacent Gold gives 3x more gold.",
        "gold per turn": "2" 
    },
    {
        "item": "Goose",
        "rarity":"common",
        "description": "Has a 1% chance of adding a Golden Egg",
        "gold per turn": "1" 
    },
    {
        "item": "Bee",
        "rarity":"uncommon",
        "description": "Adjacent Flowers give 2x more gold",
        "gold per turn": "1" 
    },
    {
        "item": "Golden Egg",
        "rarity":"rare",
        "description": "",
        "gold per turn": "3" 
    },
    {
        "item": "Cat",
        "rarity":"common",
        "description": "",
        "gold per turn": "1" 
    },
    {
        "item": "Void Stone",
        "rarity":"uncommon",
        "description": "Adjacent empty squares give 1 coin more. Destroys itself if adjacent to 0  empty squares. Gives 8 coins when destroyed",
        "gold per turn": "0" 
    },
]


app.get("/api/items", (req, res) => {
    Item.find().exec().then(
        (result) => {
            console.log(result)
            res.send(result)
        }
    ).catch(
        (err) => {
            console.log(err)
            res.status(500).send("Error Occured when getting items from database")
        }
    )
})


app.get("/api/items/:item_name", (req,res) => {
    let item = req.params.item_name
    Item.find({name:item}).exec().then(
        (results) => {
            if (results.length === 0) {
                res.status(404).send({msg:`Sorry, could not find item named: ${item}`})
                console.log("No results found.")
            }
            else {
                console.log(results)
                return res.send(results)
            }
        } 
    ).catch(
        (error) => {
            console.log(error)
        }
    )      
})

app.post("/api/items", (req, res) => {
    let itemToInsert = req.body
    console.log(`User wants to insert this item: ${itemToInsert.item}`)
    if ("item" in req.body && "rarity" in req.body) {

        Item.create(req.body).then(
            (result) => {

                res.status(201).send("Insert success!")
            }
        ).catch(
            (err) => {
                console.log(`Error`)
                console.log(err)
                const msg = {
                    statusCode:500,
                    msg: "Item name or rarity might be missing"
                }
                res.status(500).send(msg)
            }
        )
    }
})

app.put("/api/items/:item_id", (req,res) => {

    Item.findOneAndUpdate({_id:req.params.item_id},req.body,{new:true}).exec().then(
        (updatedItem) => {
            if (updatedItem === null) {
                console.log("Could not find the Item to update.")   
                res.status(404).send("Could not find the Item to update.")
            }
            else {
                console.log(updatedItem)
                res.status(200).send(updatedItem)
            }
        }
    ).catch(
        (err) => {
            console.log(err)   
            res.status(500).send("Error with the update")  
        }
    )
})

app.delete("/api/items/:item_name", (req,res) => {
    const itemName = req.params.item_name

    Item.findOneAndDelete({name: itemName}).exec().then(
        (deletedItem) => {
            if (deletedItem === null) {           
                console.log("Could not find an item to delete")
            }
            else {
                console.log(deletedItem)
            }
        }
    ).catch(
        (err) => {
            console.log(err)
        }
    )
})

app.get("/", (req, res) => {  
    res.status(418).send({"name":"Peter", "age":99});
});

const onHttpStart = () => {
    console.log(`Server has started and is listening on port ${HTTP_PORT}`)
   }
   
mongoose.connect(mongoURL, connectionOptions).then(
    () => {
         console.log("Connected success")
         app.listen(HTTP_PORT, onHttpStart);
    }
 ).catch(
    (err) => {
        console.log("Error connecting to database")
        console.log(err)
    }
 )


